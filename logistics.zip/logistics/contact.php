
<?php include 'header.php'; ?>

<section class="banner_area">
<div class="container">
<div class="pull-left">
<h3>Contact Us</h3>
</div>
<div class="pull-right">
<a href="index-2.html">Home</a>
<a href="contact2.html">Contact</a>
</div>
</div>
</section>


<section class="contact_form_area2">
<div class="container">
<div class="row">
<div class="col-md-7">
<h3 class="single_title">Contact Form</h3>
<div class="row">
<form class="contact_us_form" action="" method="post" id="phpcontactform">
<div class="form-group col-md-6">
<input type="text" class="form-control" id="name" name="name" placeholder="Your Name">
</div>
<div class="form-group col-md-6">
<input type="email" class="form-control" id="email" name="email" placeholder="Email">
</div>
<div class="form-group col-md-12">
<input type="text" class="form-control" id="subject" name="subject" placeholder="Subject">
</div>
<div class="form-group col-md-12">
<textarea class="form-control" id="message" name="message" placeholder="Message" rows="1"></textarea>
</div>
<div class="form-group col-md-12 button_area">
<button type="submit" value="submit your quote" name="submit" class="btn submit_blue form-control" id="js-contact-btn">Send message <i class="fa fa-angle-right"></i></button>
<div id="js-contact-result" data-success-msg="Success, We will get back to you soon" data-error-msg="Oops! Something went wrong"></div>
</div>
</form>
</div>
</div>
<div class="col-md-5">
<h3 class="single_title">Contact Details</h3>
<div class="contact_details_inner">
<div class="media">
<div class="media-left">
<i class="fa fa-map-marker"></i>
</div>
<div class="media-body">
<p>18 Pushkina street, </p>
<p>Grodno state. Belarus</p>
</div>
</div>
<div class="media">
<div class="media-left">
<i class="fa fa-envelope-o"></i>
</div>
<div class="media-body">
<a href="#"><span class="__cf_email__">info@boltcourierservice.com </span></a>
<a href="#"><span class="__cf_email__"> help@boltcourierservice.com</span></a>
</div>
</div>
<div class="media">
<div class="media-left">
<i class="fa fa-phone"></i>
</div>
<div class="media-body">
<a href="#">+37-529-5740-312</a>
<a href="#">+35-193-4873-473</a>
</div>
</div>
</div>
</div>
</div>
</div>
</section>



<div class="google-map" id="gmaps" data-lat="40.6700" data-lon="-73.9400" data-maps-apikey="AIzaSyDMTUkJAmi1ahsx9uCGSgmcSmqDTBF9ygg" data-zoom="11"></div>

<?php include 'footer.php'; ?>
	    <?php
		include ('admin/db.php');

   if(isset($_POST['submit'])){
	
//getting text data from fields
	
	$name			 = $_POST['name'];
	$email			 = $_POST['email'];
	$subject		 = $_POST['subject'];
	$message		 = $_POST['message'];
	
	$query = "INSERT INTO contact (name, email, subject, message, date) VALUE ('$name', '$email', '$subject', '$message', now())";
	
    $insert = mysqli_query($con, $query);
	
		
  if($insert){
	
   echo "<script>alert('Message sent successful!')</script>";
   echo "<script> window.open('contact.php','_self')</script>";
		
	}
   }
    ?>