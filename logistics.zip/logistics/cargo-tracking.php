<?php include 'header.php'; ?>

<section class="banner_area">
<div class="container">
<div class="pull-left">
<h3>Cargo Tracking</h3>
</div>
<div class="pull-right">
<a href="index.php">Home</a>
<a href="cargo-tracking.php">Cargo Tracking</a>
</div>
</div>
</section>


<section class="tracking_search_area">
<div class="container">
<div class="tracking_search_inner">
<h2 class="single_title">Track your Shipment</h2>
<h5>Enter a tracking number, and get tracking results.</h5>
<form class="" method="post" action=""> 
<div class="input-group">
<input type="search" name="track" class="form-control"maxlength="9" placeholder="Tracking Number">
<span class="input-group-btn">
<button class="btn btn-default" type="submit"><i class="fa fa-circle-o-notch" aria-hidden="true"></i> Track</button>
</span>
</div>
</form>
</div>
</div>
</section>



<section class='timeline_tracking_area'>
<div class='container'>
<div class='timeline_tracking_inner'>
<div class='timeline_tracking_box'>
<?php 
$con=mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'not connected to server';
}
if(!mysqli_select_db($con,'bolt'))
{
	echo 'database not selected';
} 

include 'functions.php'; 

$track="";
$location="";
$status="";
$comment="";
$time="";
if (isset($_POST['track'])){
	$track = stripslashes($_REQUEST['track']);
	$track = mysqli_real_escape_string($con,$track);
	$query = "SELECT * FROM `track` WHERE cid='$track' limit 7";

	$result = mysqli_query($con,$query);
	$count=mysqli_num_rows($result);
		if($count==0){
			echo"
				<div class='col-md-3'></div>
				<div class=col-md-6'>
					<div class='alert alert-danger'> invalid tracking number!! try again </div>
				</div>
				<div class='col-md-3'></div>
				";
		}
	confirm_query($result);
	while ($row= mysqli_fetch_assoc($result)){
	global $location;
	$location =$row['current_city'];
	global $status;
	$status =$row['status'];
	global $comment;
	$comment =$row['comments'];
	global $time;
	$time =$row['bk_time'];
	$date = strtotime($time);
	$date1 = date('M j, Y', $date);
	$time1 = date('g:i a', $date);
	
	echo"
		<div class='tracking_list'>
		<ul>
		<li>
		<div class='checkpoint__time'><strong> $date1 </strong><div class='hint'>$time1</div></div>
		<div class='checkpoint__icon delivered'></div>
		<div class='checkpoint__content'><strong>$status/$comment<span class='checkpoint__courier-name'>BCS</span></strong><div class='hint'>$location(BCS)</div></div>
		</li> 
		</ul>
		</div>";
	}
}
?>  

		</div>
		</div>
		</div>
		</section>

<?php include 'footer.php'; ?>