<?php include 'header.php'; ?>


<section class="banner_area">
<div class="container">
<div class="pull-left">
<h3>Our Services</h3>
</div>
<div class="pull-right">
<a href="index.php">Home</a>
<a href="service.php">Services</a>
</div>
</div>
</section>


<section class="service_area">
<div class="container">
<div class="row service_list_inner">
<div class="col-md-4">
<div class="left_s_list">
<ul class="nav nav-tabs" role="tablist">
<li class="active"><a href="service-detail.html">Ground Shipping</a></li>
<li><a href="">Large Projects</a></li>
<li><a href="">International Air Freight</a></li>
<li><a href="">Contract Logistics</a></li>
<li><a href="">Warehousing</a></li>
<li><a href="">Consulting</a></li>
</ul>
<div class="download_btn">
<a href="#">Download case study <i class="fa fa-cloud-download" aria-hidden="true"></i></a>
<a href="#">Download brochure<i class="fa fa-cloud-download" aria-hidden="true"></i></a>
</div>
</div>
</div>
<div class="col-md-8">
<div class="row service_list_item_inner">
<div class="col-md-6 col-xs-6">
<div class="image_s_list">
<img src="img/services_thumb1.jpg" alt="">
<h3 class="single_title">Ground Shipping</h3>
<p>We have a wide experience in overland industry specific logistic solutions like pharmaceutical logistics, retail and automotive logistics by train or road.</p>
<a class="more_btn" href="#"><i class="fa fa-angle-right"></i></a>
</div>
</div>
<div class="col-md-6 col-xs-6">
<div class="image_s_list">
<img src="img/services_thumb2.jpg" alt="">
<h3 class="single_title">Large Projects</h3>
<p>Delivery of any freight from a place to another place quickly to save your cost and your time. Specialises in international freight forwarding of merchandise and general logistic services.</p>
<a class="more_btn" href="#"> <i class="fa fa-angle-right"></i></a>
</div>
</div>
<div class="col-md-6 col-xs-6">
<div class="image_s_list">
<img src="img/services_thumb3.jpg" alt="">
<h3 class="single_title">International Air Freight</h3>
<p>There are many variations of passages of available, but the majority have suffered alteration in some form, by or randomised slightly believable.</p>
<a class="more_btn" href="#"> <i class="fa fa-angle-right"></i></a>
</div>
</div>
<div class="col-md-6 col-xs-6">
<div class="image_s_list">
<img src="img/services_thumb4.jpg" alt="">
<h3 class="single_title">Contract Logistics</h3>
<p>We bring your goods safely to worldwide destinations with our great sea fright services.We offer LLC and FLC shipments that are fast and effective with no delays.</p>
<a class="more_btn" href="#"> <i class="fa fa-angle-right"></i></a>
</div>
</div>
<div class="col-md-6 col-xs-6">
<div class="image_s_list">
<img src="img/services_thumb5.jpg" alt="">
<h3 class="single_title">Warehousing</h3>
<p>Our warehousing services are known nationwide to be one of the most reliable and affordable, because we take pride in delivering the best of warehousing services, at the most reasonable prices.</p>
<a class="more_btn" href="#"> <i class="fa fa-angle-right"></i></a>
</div>
</div>
<div class="col-md-6 col-xs-6">
<div class="image_s_list">
<img src="img/services_thumb6.jpg" alt="">
<h3 class="single_title">Consulting</h3>
<p>Our expertise in transport management and planning allows us to design a solution. Ground transportation options for all visitors, no matter your needs, schedule or destination.</p>
<a class="more_btn" href="#"> <i class="fa fa-angle-right"></i></a>
</div>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="question_contact_area">
<div class="container">
<div class="pull-left">
<h4>Have you question or need any help for work consultant</h4>
</div>
<div class="pull-right">
<a class="more_btn" href="contact.php">Contact Us</a>
</div>
</div>
</section>
<?php include 'footer.php'; ?>