
<?php include 'header.php'; ?>


<section class="banner_area">
<div class="container">
<div class="pull-left">
<h3>Request a quote</h3>
</div>
<div class="pull-right"> <a href="index.php">Home</a> <a href="request-quote.php">Quote</a> </div>
</div>
</section>
<hr>
<div class="col-md-3"></div>
<div class="col-md-6">
<?php

if(isset($_POST['add'])){
$con=mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'not connected to server';
}
if(!mysqli_select_db($con,'bolt'))
{
	echo 'database not selected';
} 



$s_name=$_POST['s_name'];
$s_phone=$_POST['s_phone'];
$s_email=$_POST['s_email'];
$s_address=$_POST['s_address'];
$r_name=$_POST['r_name'];
$r_phone=$_POST['r_phone'];
$r_email=$_POST['r_email'];
$r_address=$_POST['r_address'];
$ship_type=$_POST['ship_type'];
$invoice=$_POST['invoice'];
$weight=$_POST['weight'];
$quantity=$_POST['quantity'];
$shipping=$_POST['shipping'];
$dept_place=$_POST['dept_place'];
$booking=$_POST['booking'];
$destination=$_POST['destination'];

$today = date("m");
$rand = strtoupper(substr(uniqid(sha1(time())),0,4));
$unique = 'BCS' . $today . $rand;

$sql="INSERT INTO quote(cid,s_name,s_phone,s_email,s_address,r_name,r_phone,r_email,r_address,ship_type,invoice,weight,quantity,shipping,dept_place,booking,destination) VALUES
('$unique','$s_name','$s_phone','$s_email','$s_address','$r_name','$r_phone','$r_email','$r_address','$ship_type','$invoice','$weight','$quantity','$shipping','$dept_place','$booking','$destination')";

if(!mysqli_query($con,$sql))
{
	echo '<div class="alert alert-danger alert-dismissable">
             <button type="button" class="close" data-dismiss="alert"
             aria-hidden="true">
             &times;
             </button>
             Sorry! something went wrong.Please try again.
            </div>';
}
else
{
	echo '<div class="alert alert-success alert-dismissable">
     <button type="button" class="close" data-dismiss="alert"
     aria-hidden="true">
     &times;
     </button>
     Success! request was successful.
    </div>';
}

	$sql2="INSERT INTO track(cid,current_city,status,comments) VALUES ('$unique','$dept_place','Pickup','Your package has been fulfilled')";
	
	if(!mysqli_query($con,$sql2))
	{
		echo '<div class="alert alert-danger alert-dismissable">
             <button type="button" class="close" data-dismiss="alert"
             aria-hidden="true">
             &times;
             </button>
             Sorry! something went wrong with tracking your package.Please try again.
            </div>';
}
else
{
	echo '<div class="alert alert-success alert-dismissable">
     <button type="button" class="close" data-dismiss="alert"
     aria-hidden="true">
     &times;
     </button>
     Success! The package has been booked for shipment.
    </div>';
}

}

?>
</div>

<div class="col-md-3"></div>
<section class="contact_form_area2">
<div class="container">
<form class="contact_us_form" action="" method="post" id="phpcontactform">
<div class="row">
<div class="col-md-6">
<h3 class="single_title">Shipper Infomation</h3>
<div class="form-group"> <label for="">Shipper Name</label> <input type="text" class="form-control" id="weight" name="s_name" placeholder="Shipper Name" required> </div>
<div class="form-group"> <label for="">Shipper Phone  No</label> <input type="text" class="form-control" id="weight" name="s_phone" placeholder="Shipper Phone  No" required> </div>
<div class="form-group"> <label for="">Shipper Email</label> <input type="text" class="form-control" id="weight" name="s_email" placeholder="Shipper Phone  No" required> </div>
<div class="form-group"> <label for="">Shipper Address </label> <textarea class="form-control" id="instructions" name="s_address" placeholder="Shipper Address" rows="3"></textarea> </div>
</div>

<div class="col-md-6">
<h3 class="single_title">Recevier Infomation</h3>
<div class="form-group"> <label for="">Recevier Name</label> <input type="text" class="form-control" id="weight" name="r_name" placeholder="Recevier Name" required> </div>
<div class="form-group"> <label for="">Recevier Phone  No</label> <input type="text" class="form-control" id="weight" name="r_phone" placeholder="Shipper Phone  No" required> </div>
<div class="form-group"> <label for="">Recevier Email</label> <input type="text" class="form-control" id="weight" name="r_email" placeholder="Shipper Phone  No" required> </div>
<div class="form-group"> <label for="">Recevier Address </label> <textarea class="form-control" id="instructions" name="r_address" placeholder="Recevier Address" rows="3"></textarea> </div>
</div>

<div class="col-md-3"></div>
<div class="col-md-6">
<br>
<br>
<h3 class="single_title">Shippment Infomation</h3>
<div class="form-group"> <label for="">Type of shippment</label> <input type="text" class="form-control" id="" name="ship_type" placeholder="Type of shippment" required> </div>
<div class="form-group"> <label for="">Weight</label> <input type="text" class="form-control" id="" name="weight" placeholder="Weight" required> </div>
<div class="form-group"> <label for="">Invoice Number</label> <input type="text" class="form-control" id="" name="invoice" placeholder="Invoice Number" required> </div>
<div class="form-group"> <label for="">Quantity</label> <input type="text" class="form-control" id="" name="quantity" placeholder="Quantity" required> </div>
<div class="form-group"> <label for="">Booking Mode</label> <input type="text" class="form-control" id="" name="booking" placeholder="Booking Mode" required> </div>
<div class="form-group"> <label for="">Departure Location</label> <input type="text" class="form-control" id="departure" name="dept_place" placeholder="Enter City" required> </div>
<div class="form-group"> <label for="">Destination</label> <input type="text" class="form-control" id="" name="destination" placeholder="Enter City" required> </div>
<div class="form-group"> <label for="">Mode of Shipping</label> <select name="shipping" id="" class="form-control" required>
<option value="">Select Option</option>
<option value="Air">Air</option>
 <option value="Road">Road</option>
<option value="Train">Train</option>
<option value="Sea">Sea</option>
</select> </div>
</div>

<div class="col-md-3">
</div>
<div class="form-group col-md-12 button_area text-center mt-3"> <button type="submit" name="add" value="submit your quote" class="btn submit_blue form-control">Request Quote
<i class="fa fa-angle-right"></i></button> </div>
<div class="col-md-12">
<div id="js-contact-result" data-success-msg="Success, We will get back to you soon" data-error-msg="Oops! Something went wrong"></div>
</div>
</div>
</form>
</div>
</section>


<?php include 'footer.php'; ?>