<?php include 'header.php'; ?>


<section class="banner_area">
<div class="container">
<div class="pull-left">
<h3>About Us</h3>
</div>
<div class="pull-right">
<a href="index.php">Home</a>
<a href="about.php">About Us</a>
</div>
</div>
</section>


<section class="our_about_area">
<div class="container">
<div class="row">
<div class="col-md-4">
<div class="our_about_image">
<img src="img/about-right-1.jpg" alt="">
</div>
</div>
<div class="col-md-8">
<div class="our_about_left_content">
<h3 class="single_title">About Us</h3>
<p>At Blot Courier Services we pride ourselves as being world’s Leading Logistics Company. Founded in 2012, we belong to a distinguished class of logistics companies with a clear defined market path across world.
<br>
We are expanding rapidly with scores of local branches in Belarus and a wide robust global network providing domestic and international intra and inter-state express delivery services.<br>

Our footprints are also clearly visible in the areas of freight forwarding, haulage services, mail room services, warehousing and distribution services and e-commerce logistics. Our rapid growth has largely been propelled by an excellent team of professionals.</p>
<p>

Blot Courier Services prides itself as an operator with the most knowledge of the local environment. Backed by a seamless infrastructure, we are now positioned more than ever to compete with other globally-rated logistics company.<br>

Our tagline ‘world’s Leading Logistics Company’, is an affirmation of our excellent processes, technological innovation and customer care deliverables backed up with a World class team. This mantra is brought alive in our speedy response to pick-up operations, prompt and secure delivery of shipments and comparative friendly charges.</p>
</div>
</div>
</div>
</div>
</section>


<section class="global_text_area">
<div class="container">
<div class="row">
<div class="col-md-6">
<div class="global_text_item">
<h3 class="single_title">Our Global Mission</h3>
<p>Dynamically embrace accurate scenarios with quality ROI. Credibly predominate extensive intellectual capital whereas visionary data. Quickly facilitate flexible scenarios with team building resources. Continually leverage existing
efficient relationships vis-a-vis user-centric technology. Seamlessly implement multidisciplinary human capital through 24/7 methodologies. </p>
</div>
</div>
<div class="col-md-6">
<div class="global_text_item">
<h3 class="single_title">We Are Growing Faster</h3>
<p>Objectively brand client-centric processes with professional results. Credibly orchestrate virtual resources and dynamic expertise. Interactively maintain leveraged users with empowered scenarios. Dynamically procrastinate best-of-breed
quality vectors without bleeding-edge growth strategies. Continually restore goal-oriented growth strategies</p>
</div>
</div>
</div>
</div>
</section>


<section class="why_choose_area">
<div class="why_choose_image">
<img src="img/why-us-img.jpg" alt="">
</div>
<div class="why_choose_feature">
<div class="why_choose_content">
<h3 class="single_title">TECHNOLOGY AND ENGINEERING</h3>
<h6>Credibly orchestrate virtual resources and dynamic expertise. Interactively maintain leveraged users.</h6>
<p>Competently deliver e-business users via economically sound supply chains. Assertively reconceptualize error-free e-markets whereas focused schemas. Phosfluorescently embrace process-centric niche markets before orthogonal platforms. </p>
</div>
</div>
</section>


<section class="client_logo_area white_client">
<div class="container">
<div class="client_slider owl-carousel">
<div class="item">
<img src="img/client-logo/client-1.png" alt="">
</div>
<div class="item">
 <img src="img/client-logo/client-2.png" alt="">
</div>
<div class="item">
<img src="img/client-logo/client-3.png" alt="">
</div>
<div class="item">
<img src="img/client-logo/client-4.png" alt="">
</div>
<div class="item">
<img src="img/client-logo/client-5.png" alt="">
</div>
</div>
</div>
</section>


<section class="subscribe_form">
<div class="container">
<div class="row">
<div class="col-lg-6">
<h4>Subscribe to our corporate newsletter</h4>
</div>
<div class="col-lg-6">
<form action="https://demo.web3canvas.com/themeforest/startly/logistics/php/subscribe.php" class="form-inline" method="post" id="subscribeform">
<div class="form-group"> <input type="email" name="email" class="form-control" placeholder="Enter your email..."> </div>
<div class="form-group"> <button class="btn" type="submit" id="js-subscribe-btn"> Subscribe </button> </div>
<div id="js-subscribe-result" class="text-center" data-success-msg="Almost finished. Please check your email and verify." data-error-msg="Oops. Something went wrong."></div>
</form>
</div>
</div>
</div>
</section>
<?php include 'footer.php'; ?>