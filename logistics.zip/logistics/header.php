<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.web3canvas.com/themeforest/startly/logistics/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Jun 2020 23:09:54 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="../../../cdn-cgi/apps/head/-mEFVS8y7qx5pVzWHQTCQu5gnVM.js"></script><link rel="icon" href="img/fav-icon.png" type="image/x-icon" />

<title>Blot Courier Services</title>

<link href="css/font-awesome.min.css" rel="stylesheet">

<link href="css/bootstrap.min.css" rel="stylesheet">

<link href="vendors/revolution/css/settings.css" rel="stylesheet">
<link href="vendors/revolution/css/layers.css" rel="stylesheet">
<link href="vendors/revolution/css/navigation.css" rel="stylesheet">
<link href="vendors/animate-css/animate.css" rel="stylesheet">

<link href="vendors/owl-carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="vendors/magnific-popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">


<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>
<body>

<header class="main_header_area">
<div class="header_top">
<div class="container">
<div class="pull-left">
<a href="index-2.html"><img src="img/logo.png" alt=""></a>
</div>
<div class="pull-right">
<div class="header_c_text">
<h5>Call us</h5>
<h4>+37-529-5740-312</h4>
<h4>+35-193-4873-473</h4>
</div>
<div class="header_c_text">
<h5>Working Hours</h5>
<h4>Mon - Fri 8am to 10pm</h4>
</div>
<div class="header_c_text">
<h5>info@boltcourierservice.com</h5>
<h4> </h4>
</div>
<div class="header_c_text">
<a class="quote_btn" href="request-quote.html">Sign in</a>
</div>
</div>
</div>
</div>
<div class="main_menu_area">
<nav class="navbar navbar-default">
<div class="container">

<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>

<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav">
<li class="active"><a href="index.php">Home</a></li>
<li><a href="about.php">About Us</a></li>
<li><a href="service.php">Service</a></li>
<li><a href="cargo-tracking.php">Cargo Tracking</a></li>
<li><a href="request-quote.php">Request a Quote</a></li>
<li><a href="contact.php">Contact</a></li>
</ul>
<ul class="nav navbar-nav navbar-right">
<li>
<div class="input-group">
<input type="text" class="form-control" placeholder="Search here...">
<span class="input-group-btn">
<button class="btn btn-default" type="button"><i class="fa fa-search" aria-hidden="true"></i></button>
</span>
</div>
</li>
</ul>
</div>

</div>

</nav>
</div>
</header>
