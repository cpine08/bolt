<?php include ('db.php'); ?>
    <div class="row">
		<div class="box col-md-12">
			<div class="box-inner">
				<div class="box-header well" data-original-title="">
					<h2><i class="glyphicon glyphicon-user"></i> View Shipment</h2>

				</div>
				
				<div class="box-content">
					<table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
						<thead>
							<tr>
								<th>S/N</th>
								<th>Tracking ID</th>
								<th>Origin</th>
								<th>Destination</th>
								<th>Pickup Date </th>
								<th>Status</th>
								<th> </th>
							</tr>
						</thead>
						<?php
	
							$get_shp = "select * from quote";
							$run_shp = mysqli_query($con, $get_shp);
							$i = 0;
							while ($row_shp=mysqli_fetch_array($run_shp))
							{
								$ship_id		= $row_shp['id'];
								$shipTrack 		= $row_shp['cid'];
								$shipOrigin		= $row_shp['dept_place'];
								$shipDes		= $row_shp['destination'];
								$shipPick 		= $row_shp['dept_time'];
								$i++;
						
						?>
						<tbody>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $shipTrack ;?></td>
								<td class="center"><?php echo $shipOrigin ;?></td>
								<td class="center"><?php echo $shipDes ;?></td>
								<td class="center"><?php echo $shipPick ;?></td>
								<td class="center">
									<span class="label-success label label-default">Active</span>
								</td>
								<td class="center">
									<a class="btn btn-info" href="index.php?edit_ship=<?php echo $ship_id;?>">
										<i class="glyphicon glyphicon-edit icon-white"></i>
										Edit
									</a>
									<a class="btn btn-danger" href="delete_ship.php?delete_ship=<?php echo $ship_id;?>">
										<i class="glyphicon glyphicon-trash icon-white"></i>
										Delete
									</a>
								</td>
							</tr>
						</tbody>
					<?php } ?>
					</table>
				</div>
			</div>
		</div>
    <!--/span-->

    </div><!--/row-->