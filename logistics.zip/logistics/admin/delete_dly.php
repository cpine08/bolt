<?php 

include ("db.php");

if(isset($_GET['delete_dly']))
	{
		$delete_id = $_GET['delete_dly'];
		$delete_dly = "delete from track where id ='$delete_id'";
		   $run_delete = mysqli_query($con, $delete_dly );
	
		
  if($run_delete){
	
   echo "<script>alert('delivery info has been deleted!')</script>";
   echo "<script> window.open('index.php?view_dly','_self')</script>";
		
	}
   }
    ?>