<?php
include ('db.php');


?>
    <div class="row">
        <div class="box col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-user"></i> Responsive, Swipable Table</h2>

                    <div class="box-icon">
                        <a href="#" class="btn btn-minimize btn-round btn-default"><i
                                class="glyphicon glyphicon-chevron-up"></i></a>
                        <a href="#" class="btn btn-close btn-round btn-default"><i
                                class="glyphicon glyphicon-remove"></i></a>
                    </div>
                </div>
                <div class="box-content">
                    <table class="table table-striped table-bordered responsive">
					
						<?php if (isset($_GET['edit_ship']))
							{
								$get_id = $_GET['edit_ship'];
								$get_ship = "select * from quote where id ='$get_id'";
								$run_ship = mysqli_query($con, $get_ship);
								$row_ship=mysqli_fetch_array($run_ship);
								
								$ship_id 		= $row_ship['id'];
								$ship_name		= $row_ship['s_name'];
								$ship_phone 	= $row_ship['s_phone'];
								$ship_email 	= $row_ship['s_email'];
								$ship_address 	= $row_ship['s_address'];
								$re_name 		= $row_ship['r_name'];
								$re_phone 		= $row_ship['r_phone'];
								$re_email 		= $row_ship['r_email'];
								$re_address 	= $row_ship['r_address'];
								$track		 	= $row_ship['cid'];
								$weight		 	= $row_ship['weight'];
								$ship_type		= $row_ship['ship_type'];
								$mode			= $row_ship['shipping'];
								$origin			= $row_ship['dept_place'];
								$destination	= $row_ship['destination'];
								$time			= $row_ship['dept_time'];
								$comment		= $row_ship['comments'];
							
						?>
                        <thead>
							<tr>
								<th>
									<p><span>Shipper Name: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span> <span><i><font color="#309"> <?php echo $ship_name ;?></font></i> </span> </p>
									<p><span>Shipper Phone: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span> <span><i><font color="#309"> <?php echo $ship_phone ;?></font></i> </span> </p>
									<p><span>Shipper Email: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span> <span><i><font color="#309"> <?php echo $ship_email ;?></font></i> </span> </p>
									<p><span>Shipper Address: &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span> <span><i><font color="#309"> <?php echo $ship_address ;?></i> </span> </font></p>
								</th>
								<th>
									<p><span>Receiver Name: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span> <span><i><font color="#060"> <?php echo $re_name ;?></font></i> </span> </p>
									<p><span>Receiver Phone: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span> <span><i><font color="#060"> <?php echo $re_phone ;?></font></i> </span> </p>
									<p><span>Receiver Email: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span> <span><i><font color="#060"> <?php echo $re_email ;?></font></i> </span> </p>
									<p><span>Receiver Address: &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span> <span><i><font color="#060"> <?php echo $re_address ;?></font></i> </span> </p>
							</tr>
                        </thead>
                        <tbody>
							<tr>
								<td>Tracking No:</td>
								<td><?php echo $track ;?></td>
							</tr>
							<tr>
								<td>ship Type</td>
								<td><?php echo $ship_type ;?></td>
							</tr>
							<tr>
								<td>Weight</td>
								<td><?php echo $weight ;?></td>
							</tr>
							<tr>
								<td>Mode</td>
								<td><?php echo $mode; ?></td>
							</tr>
							<tr>
								<td>Origin</td>
								<td><?php echo $origin; ?></td>
							</tr>
							<tr>
								<td>Destination:</td>
								<td><?php echo $destination; ?></td>
							</tr>
							<tr>
								<td>Pickup Date/Time:</td>
								<td> <?php echo $time; ?></td>
							</tr>
							<tr>
								<td>Comments:</td>
								<td><?php echo $comment; ?></td>
							</tr>
                        </tbody>
							<?php } ?>
                    </table>
                </div>
			</div>
		</div>
	</div>
    
	
	