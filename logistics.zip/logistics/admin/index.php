<?php require('includes/config.php'); 

//if not logged in redirect to login page
if(!$user->is_logged_in()){ header('Location: '); } 

//include header template
require('header.php'); 
?>


<div>
    <ul class="breadcrumb">
        <li>
            <a href="#">Home</a>
        </li>
        <li>
            <a href="#">Blank</a>
        </li>
    </ul>
</div>

<div class="row">
    <div class="box col-md-12">
        <div class="box-inner">
            <div class="box-header well" data-original-title="">
                <h2><i class="glyphicon glyphicon-star-empty"></i> Shipment Dashboard</h2>

            </div>
            <div class="box-content">
                <!-- put your content here -->
				<?php 
				if(isset($_GET['form']))
				{
					include("form.php");
				}
				
				if(isset($_GET['viewShip']))
				{
					include("view_ship.php");
				}
				
				if(isset($_GET['viewCon']))
				{
					include("viewContact.php");
				}
				
				if(isset($_GET['edit_ship']))
				{
					include("editShip.php");
				}
				
				if(isset($_GET['view_dly']))
				{
					include("view_dly.php");
				}
				if(isset($_GET['edit_dly']))
				{
					include("edit_dly.php");
				}
				
				
				
				?>
				
                <!-- End your content here -->
            </div>
        </div>
    </div>
</div><!--/row-->


<?php include('footer.php'); ?>