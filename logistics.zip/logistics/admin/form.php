<?php include("db.php"); ?>
<div class="row">
    <div class="box col-md-2">
	</div>
    <div class="box col-md-7">
        <div class="box-inner">
            <div class="box-header well" data-original-title="">
                <h2><i class="glyphicon glyphicon-edit"></i> Add Shipment</h2>

                <div class="box-icon">
                    <a href="#" class="btn btn-setting btn-round btn-default"><i
                            class="glyphicon glyphicon-cog"></i></a>
                    <a href="#" class="btn btn-minimize btn-round btn-default"><i
                            class="glyphicon glyphicon-chevron-up"></i></a>
                    <a href="#" class="btn btn-close btn-round btn-default"><i
                            class="glyphicon glyphicon-remove"></i></a>
                </div>
            </div>
            <div class="box-content">
              <h3> Shipper Info </h3>
			  <hr>
                <form action="form.php" method="POST" enctype="multipart/form-data">
					<div class="form-group">
                        <label>Shipper Name: </label>
						<input type="text"  name="sName" class="form-control" />
					</div>
				<div class="form-group">
					<label>Phone: </label>
					<input type="text"  name="sPhone" class="form-control"  required /> 
				</div>
                <div class="form-group">
                    <label>Email: </label>
					<input type="text"  name="sEmail" class="form-control"  required /> 
				</div>
                <div class="form-group">
                    <label>Address: </label>
					<input type="text"  name="sAddress" class="form-control"  required /> 
				</div>
				<hr>
              <h3> Receiver Info </h3>
			  <hr>
					<div class="form-group">
                        <label>Receiver Name: </label>
						<input type="text"  name="rName" class="form-control" />
					</div>
				<div class="form-group">
					<label>Phone: </label>
					<input type="text"  name="rPhone" class="form-control"  required /> 
				</div>
                <div class="form-group">
                    <label>Email: </label>
					<input type="text"  name="rEmail" class="form-control"  required /> 
				</div>
                <div class="form-group">
                    <label>Address: </label>
					<input type="text"  name="rAddress" class="form-control"  required /> 
				</div>
				
				<hr>
              <h3> Shipment Info </h3>
			  <hr>
					<div class="form-group">
                        <label>Type Of Shipment: </label>
						<input type="text"  name="shipmentType" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Weight: </label>
						<input type="text"  name="weight" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Courier: </label>
						<input type="text"  name="courier" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Package: </label>
						<input type="text"  name="package" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Invoice No: </label>
						<input type="text"  name="invoiceNo" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Product: </label>
						<input type="text"  name="product" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Quantity: </label>
						<input type="text"  name="qnty" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Total Freight: </label>
						<input type="text"  name="totalFreight" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Mode: </label>
						<input type="text"  name="mode" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Carrier: </label>
						<input type="text"  name="carrier" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Departure Time: </label>
						<input type="text"  name="deptTime" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Origin: </label>
						<input type="text"  name="origin" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Destination: </label>
						<input type="text"  name="destination" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Pickup Date: </label>
						<input type="date"  name="pickupDate" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Pickup Time: </label>
						<input type="time"  name="pickupTime" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Status: </label>
						<input type="text"  name="status" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Expected Delivery Date: </label>
						<input type="text"  name="dlyDate" class="form-control" />
					</div>
					<div class="form-group">
                        <label>Comments: </label>
						<input type="text"  name="comments" class="form-control" />
					</div>
                    <input type="submit" name="addShip" value="Add" class="btn btn-info" />
                </form>

            </div>
        </div>
    </div>
    <!--/span-->

</div><!--/row-->


 <?php

   if(isset($_POST['addShip'])){
	
//getting text data from fields
	
	$sName			 = $_POST['sName'];
	$sPhone			 = $_POST['sPhone'];
	$sEmail 		 = $_POST['sEmail'];
	$sAddress 		 = $_POST['sAddress'];
	$rName 			 = $_POST['rName'];
	$rPhone			 = $_POST['rPhone'];
	$rEmail			 = $_POST['rEmail'];
	$rAddress		 = $_POST['rAddress'];
	$shipmentType	 = $_POST['shipmentType'];
	$weight			 = $_POST['weight'];
	$courier		 = $_POST['courier'];
	$package		 = $_POST['package'];
	$invoiceNo		 = $_POST['invoiceNo'];
	$product		 = $_POST['product'];
	$qnty			 = $_POST['qnty'];
	$totalFreight	 = $_POST['totalFreight'];
	$mode			 = $_POST['mode'];
	$carrier		 = $_POST['carrier'];
	$deptTime		 = $_POST['deptTime'];
	$origin 		 = $_POST['origin'];
	$destination	 = $_POST['destination'];
	$pickupDate		 = $_POST['pickupDate'];
	$pickupTime		 = $_POST['pickupTime'];
	$status			 = $_POST['status'];
	$dlyDate		 = $_POST['dlyDate'];
	$comments		 = $_POST['comments'];
	$date			 = $_POST['date'];
	
						if ($trackid == "") {
							/// generate a new mid for user
							$timePart = substr(time(), 0, 3);
							
							//randomise
							$numStr = str_shuffle (123456789);
							$numPart = substr($numStr, 0, 3);
							
							$alphStr = str_shuffle("ABCDEFGHKLMNOPQRSTUVWXYZ");
							$alphPart = substr($alphStr, 0, 3);
							
							$trackid = $alphPart.$timePart.$id.$numPart;
							}
	
	$query = "INSERT INTO shipment(trackid, sName, sPhone, sEmail, sAddress, rName, rPhone, rEmail, rAddress, shipmentType, weight, courier, package, invoiceNo, product, qnty, totalFreight, mode, carrier,  deptTime, origin, destination, pickupDate, pickupTime, status, dlyDate, comments, date) VALUES('$trackid', '$sName', '$sPhone', '$sEmail', '$sAddress', '$rName', '$rPhone', '$rEmail', '$rAddress', '$shipmentType', '$weight', '$courier', '$package', '$invoiceNo', '$product', '$qnty', '$totalFreight', '$mode', '$carrier', '$deptTime', '$origin', '$destination', '$pickupDate', '$pickupTime', '$status', '$dlyDate', '$comments', '$date')";
  
    $insertShip = mysqli_query($con, $query);
	
		
  if($insertShip){
	
   echo "<script>alert('Shipment has been Added!')</script>";
   echo "<script> window.open('index.php?viewShip','_self')</script>";
		
	}
   }
    ?>

