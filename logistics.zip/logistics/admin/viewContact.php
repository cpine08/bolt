<?php include ('db.php'); ?>
    <div class="row">
		<div class="box col-md-12">
			<div class="box-inner">
				<div class="box-header well" data-original-title="">
					<h2><i class="glyphicon glyphicon-user"></i> View Shipment</h2>
				</div>
				
				<div class="box-content">
					<table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
						<thead>
							<tr>
								<th>Name</th>
								<th>Email Address</th>
								<th>Phone Number</th>
								<th>Subject</th>
								<th>Message</th>
								<th>Date</th>
							</tr>
						</thead>
						<?php
	
							$getCon = "select * from contact";
							$runCon = mysqli_query($con, $getCon);
							$i = 0;
							while ($rowCon=mysqli_fetch_array($runCon))
							{
								$conId			= $rowCon['id'];
								$conName		= $rowCon['name'];
								$conEmail 		= $rowCon['email'];
								$conPhone		= $rowCon['phone'];
								$conSub			= $rowCon['subject'];
								$conMess 		= $rowCon['message'];
								$conDate 		= $rowCon['date'];
								$i++;
						
						?>
						<tbody>
							<tr>
								<td><?php echo $conName;?></td>
								<td><?php echo $conEmail ;?></td>
								<td class="center"><?php echo $conPhone ;?></td>
								<td class="center"><?php echo $conSub ;?></td>
								<td class="center"><?php echo $conMess ;?></td>
								<td class="center"><?php echo $conDate ;?></td>
								
							</tr>
						</tbody>
	<?php } ?>
					</table>
				</div>
			</div>
		</div>
    <!--/span-->

    </div><!--/row-->