<?php include("db.php"); ?>
	<div class="row">
		<div class="box col-md-2">
		</div>
			<div class="box col-md-7">
				<div class="box-inner">
					<div class="box-header well" data-original-title="">
						<h2><i class="glyphicon glyphicon-edit"></i> Add Shipment</h2>
					</div>
						<div class="box-content">
						  <h3> Update Tracking </h3>
						  <hr>
							<form action="" method="POST" enctype="multipart/form-data">
								<div class="control-group">
									<label class="control-label" for="selectError2">Product Category</label>
									<div class="controls">
										<select data-placeholder="Select Category" name="cid" id="selectError2" data-rel="chosen">
											<option value=""></option>
												<?php
													$get_cats = "select * from track";
													$run_cats = mysqli_query($con, $get_cats);
													while ($row=mysqli_fetch_array($run_cats))
													{
													  $id= $row['id'];
													  $cid= $row['cid'];
														echo "<option value='$cid'>$cid</option>";
													}
												?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label>Update Location: </label>
									<input type="text"  name="current_city" class="form-control"  required /> 
								</div>
								<div class="form-group">
									<label>Update Status: </label>
									<input type="text"  name="status" class="form-control"  required /> 
								</div>
								<div class="form-group">
									<label>Comment: </label>
									<textarea type="text"  name="comments" class="form-control" rows="4" required > </textarea>
								</div>
								<input type="submit" name="submit" value="Update Delivery" class="btn btn-info" />
							</form>
						</div>
				</div>
			</div>
	</div>
	

 <?php 
 include ('db.php') ;

   if(isset($_POST['submit'])){
	
//getting text data from fields
	$cid 		 = $_POST['cid'];
	$current_city		 = $_POST['current_city'];
	$status			 = $_POST['status'];
	$comments			 = $_POST['comments'];
	
	$query = "INSERT INTO track (cid, current_city, status, comments) VALUES ('$cid', '$current_city', '$status', '$comments')";
	
	
    $insert_dly = mysqli_query($con, $query);
	
		
  if($insert_dly){
	
   echo "<script>alert('Tracking Updated!')</script>";
   echo "<script> window.open('index.php?view_dly','_self')</script>";
		
	}
   }
    ?>