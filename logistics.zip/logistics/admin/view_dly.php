<?php include ('db.php'); ?>
    <div class="row">
		<div class="box col-md-12">
			<div class="box-inner">
				<div class="box-header well" data-original-title="">
					<h2><i class="glyphicon glyphicon-user"></i> View Shipment</h2>

				</div>
				
				<div class="box-content">
					<table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
						<thead>
							<tr>
								<th>Tracking No</th>
								<th>Location</th>
								<th>Comment</th>
								<th>Status</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<?php
	
							$get_dly = "select * from track";
							$run_dly = mysqli_query($con, $get_dly);
							$i = 0;
							while ($row_dly=mysqli_fetch_array($run_dly))
							{
									$ship_id = $row_dly['id'];
									$dly_track = $row_dly['cid'];
									$dly_loc = $row_dly['current_city'];
									$dly_date = $row_dly['comments'];
									$dly_sta = $row_dly['status'];
								$i++;
						
						?>
						<tbody>
							<tr>
								<td><?php echo $dly_track;?></td>
								<td class="center"><?php echo $dly_loc;?></td>
								<td><?php echo $dly_date;?></td>
								<td class="center"><?php echo $dly_sta;?></td>
								<td class="center"><span class="label-success label label-default">Active</span></td>
								<td class="center">
									<a class="btn btn-danger" href="delete_dly.php?delete_dly=<?php echo $ship_id;?>">
										<i class="glyphicon glyphicon-trash icon-white"></i>
										Delete
									</a>
								</td>
							</tr>
						</tbody>
	<?php } ?>
					</table>
				</div>
			</div>
		</div>
    <!--/span-->

    </div><!--/row-->