<?php 

include ("db.php");

if(isset($_GET['delete_ship']))
	{
		$delete_id = $_GET['delete_ship'];
		$delete_shp = "delete from shipment where id ='$delete_id'";
		   $run_delete = mysqli_query($con, $delete_shp );
	
		
  if($run_delete){
	
   echo "<script>alert('shipment has been deleted!')</script>";
   echo "<script> window.open('index.php?viewShip','_self')</script>";
		
	}
   }
    ?>