
<footer class="footer_area">
<div class="footer_widget_area">
<div class="container">
<div class="row">

<div class="col-md-3 col-xs-6">
</div>

<div class="col-md-3 col-xs-6">
<aside class="f_widget about_widget">
<img src="img/footer-logo.png" alt="">
<p>We place high value on maintaining and enhancing quality in every facet of the organization</p>
<ul>
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
</ul>
</aside>
</div>
<div class="col-md-3 col-xs-6">
</div>
<div class="col-md-3 col-xs-6">
<aside class="f_widget info_widget">
<div class="f_title">
<h3>Contact</h3>
</div>
<div class="contact_details">
<p>18 Pushkina street, <br class="info_br" /> Grodno state. Belarus</p>
<p>Phone: <a href="tel:+37-529-5740-312">+37-529-5740-312</a></p>
<p>Phone: <a href="tel:+37-529-5740-312">+35-193-4873-473</a></p>
<p>Email: <a href=""><span class="__cf_email__" data-cfemail="">info@</span>boltcourierservice.com</a></p>
</div>
</aside>
</div>
</div>
</div>
</div>
<div class="footer_copy_right">
<div class="container">
<h4>Copyright ©<script> document.write(new Date().getFullYear()); </script>. All rights reserved.</h4>
</div>
</div>
</footer>


<script src="js/jquery-2.2.4.js"></script>

<script src="js/bootstrap.min.js"></script>

<script src="vendors/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="vendors/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.navigation.min.js"></script>

<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="vendors/magnific-popup/jquery.magnific-popup.min.js"></script>

<script src="vendors/jvectormap/jvectormap.min.js"></script>
<script src="vendors/jvectormap/jvectormap-worldmill.js"></script>
<script src="js/locations.js"></script>

<script src="js/script.js"></script>
</body>

<!-- Mirrored from demo.web3canvas.com/themeforest/startly/logistics/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Jun 2020 23:12:18 GMT -->
</html>